#!/bin/sh

cp -f /minipwner/minimodes/Setup_Mode/network /etc/config/network
cp -f /minipwner/minimodes/Setup_Mode/wireless /etc/config/wireless

wifi
