#/bin/sh

cp -f /minipwner/minimodes/WiFi_Client/network /etc/config/network
cp -f /minipwner/minimodes/WiFi_Client/wireless /etc/config/wireless

wifi
