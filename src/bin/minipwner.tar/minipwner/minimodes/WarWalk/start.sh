#!/bin/sh

/minipwner/kismet/kismet start &

